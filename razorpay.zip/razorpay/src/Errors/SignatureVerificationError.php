<?php

namespace Razorpay\Api\Errors;

use Exception;

class SignatureVerificationError extends Exception
{
}