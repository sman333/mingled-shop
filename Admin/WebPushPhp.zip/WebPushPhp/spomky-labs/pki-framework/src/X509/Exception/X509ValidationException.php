<?php

declare(strict_types=1);

namespace SpomkyLabs\Pki\X509\Exception;

use RuntimeException;

class X509ValidationException extends RuntimeException
{
}
